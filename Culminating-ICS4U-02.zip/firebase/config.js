const firebaseConfig = {
  apiKey: "AIzaSyDHnHYC35lGXADwFrXYNQK9ju8inJMtWjM",
  authDomain: "balloono2.firebaseapp.com",
  databaseURL: "https://balloono2-default-rtdb.firebaseio.com",
  projectId: "balloono2",
  storageBucket: "balloono2.appspot.com",
  messagingSenderId: "824777434452",
  appId: "1:824777434452:web:1bb906557fffaf1f3554c1"
};

export { firebaseConfig };
