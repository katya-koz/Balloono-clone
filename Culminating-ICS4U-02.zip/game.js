import { System } from "./firebase/system.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.8.1/firebase-auth.js"
import {
  get,
  ref
} from "https://www.gstatic.com/firebasejs/9.8.1/firebase-database.js";

import {Board} from "/gameClasses/board.js";
import {Controls} from "/gameClasses/controls.js";
import {HandleData} from "/gameClasses/dataHandler.js";
import {Player, Cell} from "/gameClasses/entities.js";
import {HandleEnvironment} from "/gameClasses/environmentHandler.js";
import {HandleSprites} from "/gameClasses/spritehandler.js"

// jsut to note... this game is not complete so there are a few bugs which i will point out in my comments... but you should just keep reloading until it works lol... the game is otherwise functional... i had a lot of fun making this i just wish i had more time to make it perfect.. but i wont abuse your extension too much 

class Game {
  static user;
  static dataHandler;
  static environmentHandler = new HandleEnvironment();
  static gameEnd = false;

  static entityMasterList = {
    player: null,
    otherPlayers: [],
    stoneBlocks: [],
    woodenBlocks: [],
    balloons: [],
    backgroundCells: [],
    splash: [],
    powerUps: [],
  }

  constructor(lobbyId, system) {
    this.lobbyId = lobbyId;
    this.system = system;
    Game.user = this.system.authApp.user.uid;
    this.getSpawn();

    setTimeout(() => { // dont be mad ik this is super hacky but its so late and ive decided to spare myself at the small cost of this timeout
      // silly firebase functions run while the rest of the program runs which leaves a lot of variables undefined when theyre needed. the timeout lets the getSpawn() function work before anythign needing its return value is called
      Game.dataHandler = new HandleData(this.system, this.lobbyId);
      this.player = new Player(this.system.authApp.user.uid, this.spawnPoint);
      Game.entityMasterList.player = this.player;
      Game.dataHandler.getStuff();
      this.controls = new Controls(this.system, this.player);
      this.board = new Board();
      Game.dataHandler.getPlayers()
      this.countUsers();
      // a lot of firebase functions like to run at their own pace which causes a lot of issues in my program... so i allow them some time to load and respond before firing the next ones that would need the previous to work... there are still rememnents of my stupid timeout solution in the form of errors when sometimes the timeout isnt enough.. in that case u shoudl jsut reload the page ahaha ...
     
    }, 500);
    setTimeout(() => {
      this.initialize();

      setInterval(function() {
        this.gameLoop();
      }.bind(this), 40);
    }, 2000);

  }
  countUsers() { // counts the users??? duhhh
    let j = 0;
    get(ref(this.system.db, `rooms/${this.lobbyId}/users`)).then((snapshot) => {
      for (let user in snapshot.val()) {
        j++;
      }
      this.userCount = j;
    });
  }
  initialize() {
    Game.dataHandler.winListener(this.userCount);
    Game.dataHandler.getStuffForOtherPlayers();
    Game.environmentHandler.initializeEnvironment();
    Game.dataHandler.exportWoodenBlocks();
    Board.spriteHandler = new HandleSprites(Game.entityMasterList.player);
    this.player.currentCell = Game.entityMasterList.backgroundCells[0][0]; //initialize to first cell AFTER environment has been initialized
    Game.dataHandler.updatePos(this.player);
    Game.dataHandler.detectServerChanges();
    this.gameLoop();
  }
  getSpawn() {
    let j = 0;
    get(ref(this.system.db, `rooms/${this.lobbyId}/users`)).then((snapshot) => {
      // is this lazy?? yes.. mayb...but i am sooo tired and i cant be bothered to think of a sick algoritm to find spawning coords... hahaha. maybe in my next life
      for (let user in snapshot.val()) {

        if (user == Game.user) {
          if (j == 0) {
            this.spawnPoint = { x: Cell.width, y: 0 }
          } else if (j == 1) {
            this.spawnPoint = { x: (Board.width - 2) * Cell.width, y: (Board.height - 3) * Cell.height }
          } else if (j == 2) {
            this.spawnPoint = { x: (Board.width - 2) * Cell.width, y: 0 }
          } else if (j == 3) {
            this.spawnPoint = { x: Cell.width - 2 * Cell.width, y: (Board.height - 3) * Cell.height }
          }
        } else {
          j++;
        }
      }
    });
  }
  gameLoop() {
    Board.updateGraphics();
    this.controls.handleDirectionChange(); // this is it... THE game.
  }
}

class GamePage {
  constructor() {
    this.system = new System();

    onAuthStateChanged(this.system.authApp.auth, (user) => {
      if (user) {
        this.createGame(); // make sure user is logged in before creating the game
      }
    })
  }
  createGame() {
    this.game = new Game(new URLSearchParams(window.location.search).get('rm'), this.system);
  }
}

new GamePage();

export {Game}

//thanks for letting us have so much creative liberty over our last project of high school... i feel like i really learned a lot. i did have a lot of things i was going to implement such as soundFX, differnet animations, countdown timers, a more user friendly website, rendering layers, ghost sprites, an end game screen... so much more... but this is what i was able to come up with in the time we had.

/// thanks again for an amazing year and thank u for being such an amazing teacher. i dont think i ever told you this, but i did write an email to mr lim when you were first supplying for mr hsiung, telling him about how much i and everyone else liked your teaching. im glad you got hired for a full time position here... thank u for being so helpful and for always smiling in class.. ill always remember you!!
//-katya

//thank you for being such a great and enthusastic teacher to all of us; you were always helpful and engaging when you teaching us, and you've made my high school experience a better once. i really wish that you were able to play our game in person, as i would've loved to see how you would customize our cat with our plethora of options.. again, thank you for teaching me and i wish you well in the future :) -adrian